﻿using System;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using Windows.Foundation;
using Windows.Storage;
using Windows.UI.Popups;
using Windows.UI.ViewManagement;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Media.Imaging;
using Windows.UI.Xaml.Navigation;


// The User Control item template is documented at http://go.microsoft.com/fwlink/?LinkId=234236

namespace VarastonHallinta
{
    public sealed partial class Varasto : Page
    {
        public object Textbox { get; private set; }

        private ObservableCollection<Ingredient> ingredients;
        private Ingredient ingredient;



        public Varasto()
        {

            this.InitializeComponent();
            ApplicationView.PreferredLaunchWindowingMode = ApplicationViewWindowingMode.PreferredLaunchViewSize;
            ApplicationView.PreferredLaunchViewSize = new Size(800, 600);

        }



        // Go back
        private void Takaisinbutton_Click(object sender, RoutedEventArgs e)
        {

            NavigateBack();
        }

        public void NavigateBack()
        {
            Frame rootFrame = Window.Current.Content as Frame;
            if (rootFrame == null) return;
            if (rootFrame.CanGoBack)
            {
                rootFrame.GoBack();
            }
        }

        // Show products(dont work properly)
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            ingredient = new Ingredient();
            ReadProducts();
            
            S1.Text = ingredient.Nimi;
            S2.Text = ingredient.Valmistaja;
            S3.Text = ingredient.Määrä;

        }

        private async void ReadProducts()
        {
            // find a file
            try
            {
                StorageFolder storageFolder = ApplicationData.Current.LocalFolder;
                Stream stream = await storageFolder.OpenStreamForReadAsync("ingredients.dat");
                // read data
                DataContractSerializer serializer = new DataContractSerializer(typeof(ObservableCollection<Ingredient>));
                ingredients = (ObservableCollection<Ingredient>)serializer.ReadObject(stream);
            }
            catch (Exception ex)
            {
                // not exists create a new collection
                ingredients = new ObservableCollection<Ingredient>();
                Debug.WriteLine(ex.Message);
            }
        }
    }
}
