﻿using System;
using System.Collections.ObjectModel;
using System.Diagnostics;
using Windows.Storage;
using Windows.Storage.Pickers;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media.Imaging;
using Windows.UI.Xaml.Navigation;

namespace VarastonHallinta
{

    public sealed partial class AddPage : Page
    {
        // add/modify product
        private Ingredient ingredient;
        // link to main page collection
        private ObservableCollection<Ingredient> ingredients;
        // product image file
        private StorageFile file;

        // constructor
        public AddPage()
        {
            this.InitializeComponent();
        }

        // page is navigated to
        protected async override void OnNavigatedTo(NavigationEventArgs e)
        {
            // add
            if (e.Parameter is ObservableCollection<Ingredient>)
            {
                ingredients = (ObservableCollection<Ingredient>)e.Parameter;
                AddButton.Content = "Lisää";
            }
            // modify
            if (e.Parameter is Ingredient)
            {
                ingredient = (Ingredient)e.Parameter;
                NimiTextBox.Text = ingredient.Nimi;
                ValmistajaTextBox.Text = ingredient.Valmistaja;
                MääräTextBox.Text = ingredient.Määrä;

                // image
                try
                {
                    StorageFolder localFolder = ApplicationData.Current.LocalFolder;
                    StorageFile file = await localFolder.GetFileAsync(ingredient.Image);
                    var stream = await file.OpenAsync(FileAccessMode.Read);
                    BitmapImage image = new BitmapImage();
                    image.SetSource(stream);
                    IngredientImage.Source = image;
                }
                catch (Exception ex)
                {
                    Debug.WriteLine("Tuotteita ei voida lukea!");
                    Debug.WriteLine(ex);
                }
                AddButton.Content = "Muokkaa";
            }
            base.OnNavigatedTo(e);
        }

        // add/modify button clicked
        private async void AddButton_Click(object sender, RoutedEventArgs e)
        {
            // add a new
            if (AddButton.Content.ToString().EndsWith("Lisää"))
            {
                ingredient = new Ingredient();
            }
            // add / modify data
            ingredient.Nimi = NimiTextBox.Text;
            ingredient.Valmistaja = ValmistajaTextBox.Text;
            ingredient.Määrä = MääräTextBox.Text;

            // copy image to app local folder
            if (file != null)
            {
                ingredient.Image = file.Name;
                await file.CopyAsync(ApplicationData.Current.LocalFolder, file.Name, NameCollisionOption.ReplaceExisting);
            }
            // add
            if (AddButton.Content.ToString().EndsWith("Lisää"))
            {
                ingredients.Add(ingredient);
            }
            NavigateBack();
        }

        // cancel button clicked
        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            NavigateBack();
        }

        // navigate back to main page
        private void NavigateBack()
        {
            Frame rootFrame = Window.Current.Content as Frame;
            if (rootFrame == null) return;
            if (rootFrame.CanGoBack)
            {
                rootFrame.GoBack();
            }
        }

        // get a new product image from the system
        private async void IngredientImage_Tapped(object sender, TappedRoutedEventArgs e)
        {
            // create file open picker
            FileOpenPicker openPicker = new FileOpenPicker();
            openPicker.ViewMode = PickerViewMode.Thumbnail;
            openPicker.SuggestedStartLocation = PickerLocationId.PicturesLibrary;
            openPicker.FileTypeFilter.Add(".jpg");
            openPicker.FileTypeFilter.Add(".png");

            // open
            file = await openPicker.PickSingleFileAsync();
            // show
            if (file != null)
            {
                var stream = await file.OpenAsync(FileAccessMode.Read);
                BitmapImage image = new BitmapImage();
                image.SetSource(stream);
                IngredientImage.Source = image;
            }
        }
    }
}