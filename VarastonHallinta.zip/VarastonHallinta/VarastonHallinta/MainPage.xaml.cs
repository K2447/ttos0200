﻿using System;
using System.Windows;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using Windows.Foundation;
using Windows.Storage;
using Windows.UI.Popups;
using Windows.UI.ViewManagement;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Media.Imaging;
using Windows.UI.Xaml.Navigation;




namespace VarastonHallinta
{

    public sealed partial class MainPage : Page
    {
        // Ingredients collection
        private ObservableCollection<Ingredient> ingredients;

        public MainPage()
        {
            this.InitializeComponent();
            
            // set window size to 800x600
            ApplicationView.PreferredLaunchWindowingMode = ApplicationViewWindowingMode.PreferredLaunchViewSize;
            ApplicationView.PreferredLaunchViewSize = new Size(800, 600);

            // read products from disk
            ReadProducts();
            // bind collection to view
            IngredientsListView.ItemsSource = ingredients;
            // select first product
            if (ingredients != null)
            {
                if (ingredients.Count > 0) IngredientsListView.SelectedIndex = 0;
            }
        }

        // maybe coming back from modify -> update product UI
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            if (IngredientsListView.SelectedIndex != -1) UpdateProduct(IngredientsListView.SelectedIndex);
            base.OnNavigatedTo(e);
        }

        // add a new product
        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(AddPage), ingredients);
        }

        // modify selected product
        private void ModifyButton_Click(object sender, RoutedEventArgs e)
        {
            int index = IngredientsListView.SelectedIndex;
            if (index != -1)
            {
                this.Frame.Navigate(typeof(AddPage), ingredients.ElementAt(index)); // send product to modify
            }
        }

        // delete button clicked, ask confirmation
        private async void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            var messageDialog = new MessageDialog("Postetaanko valittu tuote?");
            messageDialog.Commands.Add(new UICommand(
                "Ok",
                new UICommandInvokedHandler(this.Delete)));
            messageDialog.Commands.Add(new UICommand(
                "Ei",
                new UICommandInvokedHandler(this.Delete)));
            messageDialog.DefaultCommandIndex = 0;
            messageDialog.CancelCommandIndex = 1;
            await messageDialog.ShowAsync();
        }

        // delete product if OK pressed
        private void Delete(IUICommand command)
        {
            if (command.Label.Equals("Ok"))
            {
                // delete
                int index = IngredientsListView.SelectedIndex;
                if (index != -1)
                {
                    ingredients.RemoveAt(index);
                }
                // show previous
                if (index > 0) IngredientsListView.SelectedIndex = index - 1;
                // there is no previous, show first if there is some
                else if (ingredients.Count > 0) IngredientsListView.SelectedIndex = 0;
                // no products left
                else
                {

                    NimiTextBlock.Text = "";
                    ValmistajaTextBlock.Text = "";
                    MääräTextBlock.Text = "";
                    IngredientImage.Source = null;
                }
            }
        }

        // save button clicked
        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            SaveProducts();
        }

        // read products data from disk
        private async void ReadProducts()
        {
            // find a file
            try
            {
                StorageFolder storageFolder = ApplicationData.Current.LocalFolder;
                Stream stream = await storageFolder.OpenStreamForReadAsync("ingredients.dat");
                // read data
                DataContractSerializer serializer = new DataContractSerializer(typeof(ObservableCollection<Ingredient>));
                ingredients = (ObservableCollection<Ingredient>)serializer.ReadObject(stream);
            }
            catch (Exception ex)
            {
                // not exists create a new collection
                ingredients = new ObservableCollection<Ingredient>();
                Debug.WriteLine(ex.Message);
            }
        }

        // save products to disk
        private async void SaveProducts()
        {
            try
            {
                // folder
                StorageFolder storageFolder = ApplicationData.Current.LocalFolder;

                // delete file if exists
                IStorageItem productsItem = await storageFolder.TryGetItemAsync("ingredients.dat");
                if (await storageFolder.TryGetItemAsync("ingredients.dat") != null)
                {
                    await productsItem.DeleteAsync();
                }
                // -> save collection
                StorageFile productsFile = await storageFolder.CreateFileAsync("ingredients.dat", CreationCollisionOption.OpenIfExists);
                // save productss to disk
                Stream stream = await productsFile.OpenStreamForWriteAsync();
                DataContractSerializer serializer = new DataContractSerializer(typeof(ObservableCollection<Ingredient>));
                serializer.WriteObject(stream, ingredients);
                await stream.FlushAsync();
                stream.Dispose();
                ShowMessageBox("Tuotteet tallennettu!.");
            }
            catch (Exception ex)
            {
                ShowMessageBox(ex.Message);
            }
        }

        // show message box
        private async void ShowMessageBox(string message)
        {
            var messageDialog = new MessageDialog(message);
            messageDialog.Commands.Add(new UICommand("Ok"));
            messageDialog.DefaultCommandIndex = 0;
            await messageDialog.ShowAsync();
        }

        // a new product is selected from the list
        private void IngredientsListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (IngredientsListView.SelectedIndex != -1)
            {
                UpdateProduct(IngredientsListView.SelectedIndex);
            }
        }

        // update products data in UI
        private async void UpdateProduct(int index)
        {
            // product
            Ingredient Ingredient = ingredients.ElementAt(index);
            // strings
            NimiTextBlock.Text = Ingredient.Nimi;
            ValmistajaTextBlock.Text = Ingredient.Valmistaja;
            MääräTextBlock.Text = Ingredient.Määrä;
           
            // image
            try
            {
                StorageFolder localFolder = ApplicationData.Current.LocalFolder;
                StorageFile file = await localFolder.GetFileAsync(Ingredient.Image);
                var stream = await file.OpenAsync(FileAccessMode.Read);
                BitmapImage image = new BitmapImage();
                image.SetSource(stream);
                IngredientImage.Source = image;
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Tuotteita ei voida lukea levyltä");
                Debug.WriteLine(ex);
            }
        }

        private void Varasto_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(Varasto), ingredients);
        }

        // Ei toimi en tiedä mikä meni vikaan kokeiltu läpi jokainen mahdollinen tapa poistua/sulkea ohjelma
        private void button_Click(object sender, RoutedEventArgs e)
        {
            if(true)
            {
                return;
            }

            
        }

      
    }
}