﻿

using System.ComponentModel;
using System.Runtime.CompilerServices;

/// <summary>
/// A friend class to hold friend properties.
/// </summary>
namespace VarastonHallinta
{
    public class Ingredient : INotifyPropertyChanged
    {
        // Declare the event
        public event PropertyChangedEventHandler PropertyChanged;

        /// <summary>
        /// This method is called by the Set accessor of each property.
        /// The CallerMemberName attribute that is applied to the optional propertyName
        /// parameter causes the property name of the caller to be substituted as an argument.        
        /// </summary>
        protected void RaisePropertyChanged([CallerMemberName] string propertyName = null)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        private string nimi;
        public string Nimi
        {
            get { return nimi; }
            set
            {
                nimi = value;
                RaisePropertyChanged();
            }
        }

        private string määrä;
        public string Määrä
        {
            get { return määrä; }
            set
            {
                määrä = value;
                RaisePropertyChanged();
            }
        }

        private string valmistaja;
        public string Valmistaja
        {
            get { return valmistaja; }
            set
            {
                valmistaja = value;
                RaisePropertyChanged();
            }
        }


        private string image;
        public string Image
        {
            get { return image; }
            set
            {
                image = value;
                RaisePropertyChanged();
            }
        }

    }
}